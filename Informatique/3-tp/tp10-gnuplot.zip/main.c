//https://livebook.manning.com/book/gnuplot-in-action-second-edition/chapter-9/
#include "prelude.h"

int main(int argc, char * argv[]) {

  system("gnuplot -p output.gp");
  // system("gnuplot -p pingouins.gp");


  return 0;
}