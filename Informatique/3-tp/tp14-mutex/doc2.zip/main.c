#include <stdio.h>
#include <pthread.h>

int counter = 0;

void *increment(void *arg){
	int n = *(int*)arg;
	for (int i = 1; i <= n; i++) {
		counter++;
	}
	return NULL;
}

int main(void){
	int N = 1000000;
	pthread_t t1, t2;
	pthread_create(&t1, NULL, increment, &N);
	pthread_create(&t2, NULL, increment, &N); 	
	pthread_join(t1, NULL);
	pthread_join(t2, NULL);
	printf("Counter = %d\n", counter);
	return 0;
}