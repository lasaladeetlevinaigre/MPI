let counter = ref 0
let lock = Mutex.create ()

let multiple_increment n = 
	for i = 0 to n - 1 do
		Mutex.lock lock;
		(* start of critical section *) 
		counter := !counter + 1;
		(* end of critical section *) 
		Mutex.unlock lock
	done

let main () =
	let n = 1_000_000 in
	let t0 = Thread.create multiple_increment n in 
	let t1 = Thread.create multiple_increment n in 
	Thread.join t0;
	Thread.join t1;
	Printf.printf "counter = %d\n" !counter
	
let () = main ()