let n = 10_000_000
let p = 5
let nb_fils = 3

let f index =
	Printf.printf "Le fil %d a démarré\n" index; 
	for i = 1 to n * p do
		if i mod n = 0 
		then Printf.printf "Le fil %d a atteint %d.\n" index i
	done

let main () =
	Printf.printf "Initialisation des threads\n";
	let fils = Array.init nb_fils (fun i -> Thread.create f i) in 
		Printf.printf "Démarrage des threads\n";
	for i = 0 to nb_fils - 1 do
		Thread.join fils.(i) 
	done;
	Printf.printf "Fin des threads\n"

let () = main ()