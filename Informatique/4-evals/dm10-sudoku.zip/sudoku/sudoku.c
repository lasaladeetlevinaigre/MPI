// résolution du Sudoku avec le retour sur trace (backtracking)

#include "prelude.h"

int   row(int c) { return c / 9; }
int   col(int c) { return c % 9; }
int group(int c) { return 3 * (row(c) / 3) + col(c) / 3; }

bool same_zone(int c1, int c2) {
  return   row(c1) == row(c2)
      ||   col(c1) == col(c2)
      || group(c1) == group(c2);
}

// vérifie que la valeur à la position p est compatible avec les autres cases
bool check(int grid[81], int p) {
  for (int c = 0; c < 81; c++)
    if (c != p && same_zone(p, c) && grid[p] == grid[c])
      return false;
  return true;
}

// algorithme de retour sur trace (backtracking)
// entrée : grid ne contient pas de contradiction
// sortie : renvoie true si grid a pu être complétée en une solution
//          renvoie false si ce n'est pas possible *et* grid est inchangée
bool solve(int grid[81]) {
  for (int c = 0; c < 81; c++)
    if (grid[c] == 0) {
      for (int v = 1; v <= 9; v++) {
        grid[c] = v;
        if (check(grid, c) && solve(grid))
          return true;
      }
      grid[c] = 0;
      return false;
    }
  return true;
}

// compter les solutions
int count(int grid[81]) {
  for (int c = 0; c < 81; c++)
    if (grid[c] == 0) {
      int s = 0;
      for (int v = 1; v <= 9; v++) {
        grid[c] = v;
        if (check(grid, c))
          s += count(grid);
      }
    grid[c] = 0;
    return s;
  }
  return 1;
}

// pour tester
void print(int grid[81]) {
  for (int i = 0; i < 9; i++) {
    if (i % 3 == 0) printf("+---+---+---+\n");
    for (int j = 0; j < 9; j++) {
      if (j % 3 == 0) printf("|");
      printf("%d", grid[9*i+j]);
    }
    printf("|\n");
  }
  printf("+---+---+---+\n");
}

void init_grid(char *s) {
  for (int i = 0; i < 9; i++) {
    if (i % 3 == 0) printf("+---+---+---+\n");
    for (int j = 0; j < 9; j++) {
      if (j % 3 == 0) printf("|");
      if (s[9*i+j] == '0')
        printf(" ");
      else
        printf("%c", s[9*i+j]);
    }
    printf("|\n");
  }
  printf("+---+---+---+\n");
}

void solve_string(char *s) {
  int grid[81];
  for (int i = 0; i < 81; i++)
    grid[i] = s[i] - '0';
  solve(grid);
  print(grid);
}
void count_string(char *s) {
  int grid[81];
  for (int i = 0; i < 81; i++)
    grid[i] = s[i] - '0';
  printf("%d solution(s)\n", count(grid));
}