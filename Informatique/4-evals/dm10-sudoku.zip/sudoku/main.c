#include "prelude.h"
#include "sudoku.h"

int main(int argc , char * argv[]) {
  // choix d'une grille
  char *s = "200000060000075030048090100000300000300010009000008000001020570080730000090000004";
  // char *s = "103040605084000000205001400041000900050394007000000000000960080000000000000530000";
  // affichage grille initiale
  init_grid(s);
  // résolution et affichage
  solve_string(s);
  // calcul du nombre de solutions
  // count_string(s);
  return 0;
}