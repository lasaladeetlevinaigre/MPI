#include "prelude.h"

int row(int c);
int col(int c);
int group(int c);
bool same_zone(int c1, int c2);
bool check(int grid[81], int p);
bool solve(int grid[81]);
int count(int grid[81]);
void print(int grid[81]);
void init_grid(char *s);
void solve_string(char *s);
void count_string(char *s);